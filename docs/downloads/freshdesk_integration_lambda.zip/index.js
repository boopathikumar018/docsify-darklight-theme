const controller = require('./controller')

exports.handler = async (event) => {
    
    console.log("-----------------------------------------------------");
    console.log(JSON.stringify(event))
    
    let fromNumber = event.Details.ContactData.CustomerEndpoint.Address;
    
    console.log("From Number : " + fromNumber)
    
    return controller().getDetailsByPhoneNumber(encodeURIComponent(fromNumber));
};
